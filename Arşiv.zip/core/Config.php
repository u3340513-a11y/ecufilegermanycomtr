<?php

declare(strict_types=1);

namespace Core;

final class Config
{
    private static array $config = [];

    public static function load(string $basePath): void
    {
        $configPath = $basePath . '/config';
        $files = glob($configPath . '/*.php');
        $skip = ['routes', 'services'];

        foreach ($files as $file) {
            $key = basename($file, '.php');
            if (in_array($key, $skip, true)) {
                continue;
            }
            self::$config[$key] = require $file;
        }
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $keys = explode('.', $key);
        $value = self::$config;

        foreach ($keys as $k) {
            if (!is_array($value) || !array_key_exists($k, $value)) {
                return $default;
            }
            $value = $value[$k];
        }

        return $value;
    }

    public static function set(string $key, mixed $value): void
    {
        $keys = explode('.', $key);
        $config = &self::$config;

        foreach ($keys as $i => $k) {
            if ($i === count($keys) - 1) {
                $config[$k] = $value;
            } else {
                if (!isset($config[$k]) || !is_array($config[$k])) {
                    $config[$k] = [];
                }
                $config = &$config[$k];
            }
        }
    }
}
