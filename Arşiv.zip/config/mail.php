<?php

return [
    'host'       => 'mail.ecufilegermany.com.tr',
    'port'       => 465,
    'username'   => 'info@ecufilegermany.com.tr',
    'password'   => 'Ecufile.2026!',
    'encryption' => 'ssl',
    'from_email' => 'info@ecufilegermany.com.tr',
    'from_name'  => 'ECU Dosya Servis',
];
