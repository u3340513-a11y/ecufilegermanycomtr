<?php

return [
    'host'     => 'localhost',
    'port'     => '3306',
    'name'     => 'ecufilegermanyco_ecuu',
    'username' => 'ecufilegermanyco_ecuu',
    'password' => 'Zindan.11',
    'charset'  => 'utf8mb4',
];
