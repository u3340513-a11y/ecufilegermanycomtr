<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Controller;
use Core\Request;

class LandingController extends Controller
{
    public function index(Request $request): void
    {
        $this->view('landing', [], 'landing');
    }
}
